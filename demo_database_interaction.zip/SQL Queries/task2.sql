﻿/*
Написать хранимую процедуру обновления данных в таблице для MSSQL до версии 2008 и для MSSQL начиная с версии 2008.
 Процедура должна реализовывать логику добавления данных в таблицу при их отсутствии и обновлении данных в таблице при их наличии.
 */

 /*
   Clear previous runs
 */
 IF OBJECT_ID('tempdb..#storage') IS NOT NULL
    DROP TABLE #storage
go
IF OBJECT_ID('dbo.store') IS NOT NULL
    DROP procedure dbo.store;

/*
  Create objects
*/

create table #storage
  (
   dataKey int,
   dataValue int
  )

go
 create procedure dbo.store 
    @newDataKey int,
	@newDataValue int  as
   begin
   
   -- Choose branch according to server version
   if @@VERSION like '%Microsoft SQL Server 2000%' 
      or  @@VERSION like '%Microsoft SQL Server 2005%'
	     or   @@VERSION like '%Microsoft SQL Server 2008%'
	  
    begin
	   if exists (select 1 from #storage where dataKey = @newDataKey)
		begin
		  update #storage set dataValue = @newDataValue
		   where dataKey = @newDataKey
		end

		else
		 begin
		  insert #storage values ( @newDataKey, @newDataValue)
		 end
	end
	else
	 begin
	   IF OBJECT_ID('tempdb..#storage_temp') IS NOT NULL 
	          DROP TABLE #storage_temp
	  
	   create table #storage_temp  
	    (
	    dataKey int,
	    dataValue int
	    )

		insert #storage_temp values (@newDataKey, @newDataValue);

		merge #storage as TARGET
		using #storage_temp as SOURCE
		 on ( target.dataKey = SOURCE.dataKey )
		 when matched and TARGET.dataValue <> SOURCE.dataValue
		  then 
		    update set TARGET.dataValue = source.dataValue
		  when not matched by target then
		   insert  values ( source.dataKey, source.dataValue);
	 end

  end;
  
 /*
  Test usage
 */
 go
 exec dbo.store 1,2
 exec dbo.store 1,2
 exec dbo.store 1,3
 exec dbo.store 2,1
 exec dbo.store 2,2

 select * from #storage;

