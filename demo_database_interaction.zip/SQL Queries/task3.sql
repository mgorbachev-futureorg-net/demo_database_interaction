﻿/*
  Declare
*/


DECLARE @AddressParts  TABLE 
   ( 
	AddrPartId int not null,
	ParentId int,
	AddrPartTypeId int not null,
	Name varchar(256) not null
   ) 

/*
  Init 
*/
   
INSERT INTO @AddressParts 	VALUES 
	(1,null,0,'A1'),
	(2,1,0,'A2'),
	(3,null,0,'B1'),
	(4,3,0,'B2'),
	(5,4,0,'B3')

SELECT * FROM @AddressParts
 
/*
3.1.	Написать запрос, который сформирует выборку всех родительских элементов по заданному параметруAddrPartId. 
*/

declare @StartChildNodeId int;
set  @StartChildNodeId = 5;

With tblParent as
(
select AddrPartId as Id from @AddressParts  where AddrPartId= @StartChildNodeId
union all
Select tblSrc.ParentId as Id from @AddressParts tblSrc  join tblParent
 on tblSrc.AddrPartId = tblParent.Id
)
select * from tblParent --OPTION(MAXRECURSION 32767)

/*
3.2.	Написать функцию, которая по заданному параметру AddrPartId сформирует на выходе строку, содержащую полный адрес по всем родительским адресообразующим элементам
*/

;With tblParent as
(
select AddrPartId as Id, 0 as hierarchicalLevel from @AddressParts  where AddrPartId= @StartChildNodeId
union all
Select tblSrc.ParentId as Id, tblParent.hierarchicalLevel+1 as hierarchicalLevel from @AddressParts tblSrc  join tblParent
 on tblSrc.AddrPartId = tblParent.Id
),
tblParentWithNames as
 (
select tblSrc.Name, tblParent.* from tblParent join @AddressParts tblSrc on tblSrc.AddrPartId =tblParent.Id --OPTION(MAXRECURSION 32767)
)
select substring( 
        (select ', ' + Name as [text()] from tblParentWithNames
		   ORDER BY hierarchicalLevel desc
            For XML PATH ('')),2,32000) FullAddr 


