USE [ReportServer]
GO

/*
  Groom
*/
IF OBJECT_ID('dbo.sales') IS NOT NULL 
	          DROP TABLE dbo.sales

IF OBJECT_ID('dbo.goods') IS NOT NULL 
	          DROP TABLE dbo.goods

IF OBJECT_ID('dbo.employee') IS NOT NULL 
	          DROP TABLE dbo.employee


IF OBJECT_ID('dbo.addGood') IS NOT NULL 
	          DROP procedure dbo.addGood

IF OBJECT_ID('dbo.addEmployee') IS NOT NULL 
	          DROP procedure dbo.addEmployee

IF OBJECT_ID('dbo.addSale') IS NOT NULL 
	          DROP procedure dbo.addSale

IF OBJECT_ID('dbo.clearAllNotUsedGoods') IS NOT NULL 
	          DROP procedure dbo.clearAllNotUsedGoods

IF OBJECT_ID('dbo.clearAllNotUsedEmployee') IS NOT NULL 
	          DROP procedure dbo.clearAllNotUsedEmployee
/*
 Create
*/

CREATE TABLE  dbo.goods (
	 id   int  IDENTITY(1,1) NOT NULL ,
	 name   varchar (255) not NULL,
	  CONSTRAINT [dbo.PK_goods] PRIMARY KEY CLUSTERED (id ASC) 
) 


CREATE TABLE  dbo.employee (
	 id   int  IDENTITY(1,1) NOT NULL,
	 name   varchar (255) not NULL,
	   CONSTRAINT [dbo.PK_employee] PRIMARY KEY CLUSTERED (id ASC) 
) 


CREATE TABLE  dbo.sales (
     id   int  IDENTITY(1,1) NOT NULL,
	 goodId   int  NULL,
	 employeeId   int  NULL,
	 saleDate   datetime  NULL,
	 saleSum   float  NULL,
	 CONSTRAINT [dbo.PK_sales] PRIMARY KEY CLUSTERED (id ASC) ,
	 CONSTRAINT [dbo.FK_employee] FOREIGN KEY (employeeId) REFERENCES dbo.employee (id),
	 CONSTRAINT [dbo.FK_good] FOREIGN KEY (goodId) REFERENCES dbo.goods (id),
) 


go

create procedure dbo.addGood
  @name varchar(255) as
 begin
   
   if not exists (select 1 from dbo.goods  where name = @name)
    begin
	 insert dbo.goods (name) values (@name)
	end

 end;

 go
 
create procedure dbo.addEmployee
  @name varchar(255) as
 begin
   
   if not exists (select 1 from dbo.employee  where name = @name)
    begin
	 insert dbo.employee (name) values (@name)
	end

 end;

 go 

 create procedure dbo.addSale
  @employeeName varchar(255),
  @goodName varchar(255), 
  @saleDate datetime,
  @saleSum float  
  as
 begin
   
   /*
   CREATE TABLE  dbo.sales (
	 goodId   int  NULL,
	 employeeId   int  NULL,
	 saleDate   datetime  NULL,
	 saleSum   float  NULL
) 
   */

   /*
   declare @goodId  int
    select @goodId= id from dbo.goods g where  g.name = 'Good X'
	 select @goodId
   */

   declare @goodId  int
   declare @employeeId int

   select @goodId= id from dbo.goods g where  g.name = @goodName
   select @employeeId= id from dbo.employee e where  e.name = @employeeName 

   set @goodId = isnull(@goodId, -1)
   set @employeeId = isnull(@employeeId, -1)

   insert dbo.sales values (@goodId, @employeeId, @saleDate, @saleSum);   
 
 end;

go

create procedure dbo.clearAllNotUsedGoods as
 begin
   delete dbo.goods
    where id not in (select goodId from dbo.sales)
 end;

go

create procedure dbo.clearAllNotUsedEmployee as
 begin
   delete dbo.employee
     where id not in (select employeeId from dbo.sales)
 end;


 /*
  Check
 */
 go

 exec dbo.addGood 'Good A'
 exec dbo.addGood 'Good B'

 exec dbo.addEmployee 'Employee A'
 exec dbo.addEmployee 'Employee B'

 declare @currentTime datetime
 set @currentTime = GETDATE();


 exec dbo.addSale 'Employee A', 'Good A',  @currentTime , 100
 exec dbo.addSale 'Employee A', 'Good B',  @currentTime , 200

 /*
 exec dbo.clearAllNotUsedGoods
 exec dbo.clearAllNotUsedEmployee

 --*/

 select * from dbo.goods;
 select * from dbo.sales;
 select * from dbo.employee;
 